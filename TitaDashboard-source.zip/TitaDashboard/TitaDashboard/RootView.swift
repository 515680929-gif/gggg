import SwiftUI

private enum DashTab: String, CaseIterable {
    case drive = "驾驶", trips = "行程", vehicle = "车辆", tita = "TITA", settings = "设置"
    var icon: String {
        switch self { case .drive: return "speedometer"; case .trips: return "point.topleft.down.curvedto.point.bottomright.up"; case .vehicle: return "car.side"; case .tita: return "dot.radiowaves.left.and.right"; case .settings: return "slider.horizontal.3" }
    }
}

struct MainTabView: View {
    @EnvironmentObject private var store: VehicleStore
    @State private var tab: DashTab = .drive
    var body: some View {
        ZStack(alignment: .bottom) {
            Color(hex: 0x080B10).ignoresSafeArea()
            Group {
                switch tab {
                case .drive: DashboardView()
                case .trips: TripsView()
                case .vehicle: VehicleView()
                case .tita: TITAView()
                case .settings: SettingsView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            bottomBar
        }
        .statusBarHidden(false)
    }
    private var bottomBar: some View {
        HStack(spacing: 0) {
            ForEach(DashTab.allCases, id: \.self) { item in
                Button { withAnimation(.easeInOut(duration: 0.18)) { tab = item } } label: {
                    VStack(spacing: 5) {
                        Image(systemName: item.icon).font(.system(size: 19, weight: .semibold))
                        Text(item.rawValue).font(.system(size: 10, weight: .medium))
                    }
                    .foregroundStyle(tab == item ? Color(hex: 0x42D7A2) : Color(hex: 0x78818E))
                    .frame(maxWidth: .infinity).padding(.top, 12).padding(.bottom, 9)
                    .contentShape(Rectangle())
                }.buttonStyle(.plain)
            }
        }
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 0.5) }
    }
}

struct DashboardView: View {
    @EnvironmentObject private var store: VehicleStore
    @State private var detail: DetailKind?
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                header
                connectionStrip
                speedPanel
                quickStatus
                HStack(spacing: 12) {
                    MetricTile(title: "电池电量", value: String(format: "%.0f", store.data.battery), unit: "%", icon: "battery.75percent", tint: Color(hex: 0x42D7A2), foot: "预计续航 \(Int(store.data.range)) km")
                    MetricTile(title: "环境温度", value: String(format: "%.0f°", store.data.outsideTemp), unit: "C", icon: "thermometer.medium", tint: Color(hex: 0x55B9FF), foot: "电池 \(Int(store.data.batteryTemp))°C")
                }
                tireSummary
                drivingSummary
                mapPreview
                Color.clear.frame(height: 82)
            }
            .padding(.horizontal, 16).padding(.top, 8)
        }
        .sheet(item: $detail) { DetailSheet(kind: $0) }
    }
    private var header: some View {
        HStack(spacing: 10) {
            Image("dashla_dark_sm_7aea5db").resizable().scaledToFit().frame(width: 34, height: 34).clipShape(RoundedRectangle(cornerRadius: 9))
            VStack(alignment: .leading, spacing: 2) {
                Text("DASHLA").font(.system(size: 18, weight: .black, design: .rounded)).tracking(2)
                Text("\(store.selectedVehicle.uppercased())").font(.system(size: 9, weight: .semibold)).tracking(1.2).foregroundStyle(.secondary)
            }
            Spacer()
            HStack(spacing: 5) { Circle().fill(Color(hex: 0xF4B84D)).frame(width: 6, height: 6); Text("演示数据").font(.system(size: 10, weight: .medium)) }
                .foregroundStyle(Color(hex: 0xF4B84D)).padding(.horizontal, 9).padding(.vertical, 7).background(Color(hex: 0xF4B84D).opacity(0.10), in: Capsule())
            Button { detail = .settings } label: { Image(systemName: "ellipsis").font(.system(size: 17, weight: .bold)).foregroundStyle(.white).frame(width: 34, height: 34).background(Color.white.opacity(0.07), in: Circle()) }
        }
    }
    private var connectionStrip: some View {
        HStack(spacing: 10) {
            Image(systemName: "antenna.radiowaves.left.and.right").foregroundStyle(Color(hex: 0xF4B84D))
            VStack(alignment: .leading, spacing: 2) { Text("TITA 设备未连接").font(.system(size: 12, weight: .semibold)); Text("当前显示模拟车辆数据").font(.system(size: 10)).foregroundStyle(.secondary) }
            Spacer()
            Button("连接") { detail = .tita }.font(.system(size: 11, weight: .bold)).foregroundStyle(Color(hex: 0x42D7A2)).padding(.horizontal, 13).padding(.vertical, 7).background(Color(hex: 0x42D7A2).opacity(0.12), in: Capsule())
        }.padding(12).background(Color(hex: 0x171D26), in: RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.06)))
    }
    private var speedPanel: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24).fill(LinearGradient(colors: [Color(hex: 0x18232C), Color(hex: 0x10151D)], startPoint: .topLeading, endPoint: .bottomTrailing))
            VStack(spacing: 5) {
                HStack { Text("实时车速").font(.system(size: 11, weight: .semibold)).foregroundStyle(.secondary); Spacer(); Label("GPS / TITA", systemImage: "location.fill").font(.system(size: 9)).foregroundStyle(.secondary) }
                ZStack {
                    Circle().stroke(Color.white.opacity(0.07), lineWidth: 12).frame(width: 204, height: 204)
                    Circle().trim(from: 0, to: min(store.data.speed / 180, 1)).stroke(AngularGradient(colors: [Color(hex: 0x37CFA0), Color(hex: 0x53B7FF), Color(hex: 0x37CFA0)], center: .center), style: StrokeStyle(lineWidth: 12, lineCap: .round)).rotationEffect(.degrees(-90)).frame(width: 204, height: 204)
                    VStack(spacing: 0) {
                        Text("\(Int(store.data.speed))").font(.system(size: 66, weight: .light, design: .rounded).monospacedDigit()).contentTransition(.numericText())
                        Text(store.unit).font(.system(size: 12, weight: .bold)).tracking(2).foregroundStyle(Color(hex: 0x42D7A2))
                    }
                }.padding(.vertical, 7)
                HStack(spacing: 22) {
                    Label("P", systemImage: "parkingsign.circle").foregroundStyle(Color(hex: 0x42D7A2))
                    Label("\(String(format: "%.2f", store.data.gForce)) G", systemImage: "waveform.path").foregroundStyle(.secondary)
                    Label("\(Int(store.data.outsideTemp))°C", systemImage: "thermometer").foregroundStyle(.secondary)
                }.font(.system(size: 10, weight: .medium))
            }.padding(16)
        }.frame(height: 306)
    }
    private var quickStatus: some View {
        HStack(spacing: 9) {
            StatusPill(icon: "lock.fill", title: "车辆已锁", active: store.data.isLocked)
            StatusPill(icon: "figure.seated.seatbelt", title: "安全带", active: store.data.seatbelt)
            StatusPill(icon: "bolt.fill", title: "驻车", active: store.data.parkingBrake)
        }
    }
    private var tireSummary: some View {
        Button { detail = .tires } label: {
            VStack(spacing: 12) {
                HStack { SectionHeading(title: "轮胎状态", subtitle: "TPMS · 胎压 / 胎温"); Spacer(); Image(systemName: "chevron.right").font(.system(size: 12, weight: .bold)).foregroundStyle(.secondary) }
                HStack(spacing: 8) {
                    TireValue(position: "左前", pressure: store.data.frontLeftPressure, temp: store.data.frontLeftTemp)
                    TireValue(position: "右前", pressure: store.data.frontRightPressure, temp: store.data.frontRightTemp)
                    Spacer(minLength: 4)
                    Image(systemName: "car.side.fill").font(.system(size: 34)).foregroundStyle(Color.white.opacity(0.42)).rotationEffect(.degrees(-90)).frame(width: 44)
                    Spacer(minLength: 4)
                    TireValue(position: "左后", pressure: store.data.rearLeftPressure, temp: store.data.rearLeftTemp)
                    TireValue(position: "右后", pressure: store.data.rearRightPressure, temp: store.data.rearRightTemp)
                }
            }.padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 18))
        }.buttonStyle(.plain)
    }
    private var drivingSummary: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeading(title: "驾驶数据", subtitle: "本次行程概览")
            HStack(spacing: 0) {
                DataColumn(value: String(format: "%.1f", store.data.tripDistance), unit: "km", title: "行程里程")
                DataColumn(value: "\(store.data.averageConsumption)", unit: "Wh/km", title: "平均能耗")
                DataColumn(value: String(format: "%.1f", store.data.odometer), unit: "km", title: "总里程")
            }
        }.padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 18))
    }
    private var mapPreview: some View {
        Button { detail = .map } label: {
            ZStack(alignment: .bottomLeading) {
                RoundedRectangle(cornerRadius: 18).fill(LinearGradient(colors: [Color(hex: 0x1C2B34), Color(hex: 0x101820)], startPoint: .topLeading, endPoint: .bottomTrailing))
                Path { p in p.move(to: CGPoint(x: 0, y: 95)); p.addCurve(to: CGPoint(x: 360, y: 35), control1: CGPoint(x: 120, y: 20), control2: CGPoint(x: 210, y: 150)) }.stroke(Color(hex: 0x42D7A2), style: StrokeStyle(lineWidth: 3, lineCap: .round, dash: [2, 5])).padding(.horizontal, 8)
                HStack { Image(systemName: "map.fill"); VStack(alignment: .leading, spacing: 2) { Text("地图与导航").font(.system(size: 13, weight: .bold)); Text("查看位置、路线与行程轨迹").font(.system(size: 10)).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(.secondary) }.padding(14)
            }.frame(height: 125).clipShape(RoundedRectangle(cornerRadius: 18))
        }.buttonStyle(.plain)
    }
}

struct TripsView: View {
    @EnvironmentObject private var store: VehicleStore
    @State private var selected = "最近"
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                PageHeader(title: "行程", subtitle: "TRIPS & DRIVING HISTORY")
                HStack(spacing: 8) { ForEach(["最近", "本周", "本月"], id: \.self) { s in Button(s) { selected = s }.font(.system(size: 12, weight: .semibold)).foregroundStyle(selected == s ? Color.black : .secondary).padding(.horizontal, 18).padding(.vertical, 9).background(selected == s ? Color(hex: 0x42D7A2) : Color.white.opacity(0.06), in: Capsule()) } }
                HStack(spacing: 12) { SummaryCard(title: "总行程", value: "24", unit: "次", icon: "point.topleft.down.curvedto.point.bottomright.up"); SummaryCard(title: "累计里程", value: "486", unit: "km", icon: "road.lanes") }
                VStack(spacing: 0) {
                    TripRow(date: "今天 · 09:42", title: "城市通勤", route: "家 → 公司", distance: "18.6 km", duration: "32 分钟", energy: "146 Wh/km")
                    Divider().overlay(Color.white.opacity(0.06))
                    TripRow(date: "昨天 · 18:16", title: "晚间出行", route: "公司 → 家", distance: "21.3 km", duration: "38 分钟", energy: "152 Wh/km")
                    Divider().overlay(Color.white.opacity(0.06))
                    TripRow(date: "11月17日 · 14:05", title: "周末出行", route: "城市道路", distance: "46.8 km", duration: "61 分钟", energy: "139 Wh/km")
                }.padding(.horizontal, 14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 18))
                InfoBanner(text: "行程记录为演示数据。连接 TITA 后，可逐步接入真实行程与车辆传感器数据。", icon: "info.circle")
                Color.clear.frame(height: 90)
            }.padding(16)
        }
    }
}

struct VehicleView: View {
    @EnvironmentObject private var store: VehicleStore
    @State private var showingPicker = false
    @State private var detail: DetailKind?
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                PageHeader(title: "车辆", subtitle: "VEHICLE OVERVIEW")
                VStack(spacing: 12) {
                    HStack { Text("我的车辆").font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary); Spacer(); Button("更换") { showingPicker = true }.font(.system(size: 11, weight: .bold)).foregroundStyle(Color(hex: 0x42D7A2)) }
                    ZStack {
                        RoundedRectangle(cornerRadius: 18).fill(LinearGradient(colors: [Color(hex: 0x202B36), Color(hex: 0x121820)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        Image("portrait_dark_settings_vehicle_icon_picker_c39af78").resizable().scaledToFit().frame(height: 150).opacity(0.9)
                    }.frame(height: 170)
                    HStack { VStack(alignment: .leading, spacing: 3) { Text("Tesla Model 3 Performance").font(.system(size: 16, weight: .bold)); Text("2024+ · AWD · 高性能版").font(.system(size: 10)).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "checkmark.seal.fill").foregroundStyle(Color(hex: 0x42D7A2)) }
                }.padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 18))
                SectionHeading(title: "车辆状态", subtitle: "VEHICLE STATUS")
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    ActionTile(icon: "battery.75percent", title: "电池与续航", value: "\(Int(store.data.battery))% · \(Int(store.data.range)) km", tint: Color(hex: 0x42D7A2)) { detail = .battery }
                    ActionTile(icon: "thermometer.medium", title: "温度信息", value: "电池 \(Int(store.data.batteryTemp))°C", tint: Color(hex: 0x55B9FF)) { detail = .temperature }
                    ActionTile(icon: "car.side", title: "轮胎与胎压", value: "四轮状态正常", tint: Color(hex: 0xF4B84D)) { detail = .tires }
                    ActionTile(icon: "lock.fill", title: "车门与安全", value: "车辆已锁定", tint: Color(hex: 0xA78BFA)) { detail = .safety }
                }
                SectionHeading(title: "车辆信息", subtitle: "VEHICLE DETAILS")
                VStack(spacing: 0) { KeyValueRow(key: "车辆型号", value: store.selectedVehicle); KeyValueRow(key: "累计里程", value: String(format: "%.1f km", store.data.odometer)); KeyValueRow(key: "数据来源", value: "模拟数据"); KeyValueRow(key: "车辆连接", value: "尚未连接 TITA") }.padding(.horizontal, 14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 16))
                Color.clear.frame(height: 90)
            }.padding(16)
        }
        .confirmationDialog("选择车辆型号", isPresented: $showingPicker, titleVisibility: .visible) { Button("Model 3 Performance") { store.selectedVehicle = "Model 3 Performance" }; Button("Model 3") { store.selectedVehicle = "Model 3" }; Button("Model Y") { store.selectedVehicle = "Model Y" }; Button("取消", role: .cancel) {} }
        .sheet(item: $detail) { DetailSheet(kind: $0) }
    }
}

struct TITAView: View {
    @EnvironmentObject private var store: VehicleStore
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                PageHeader(title: "TITA 设备", subtitle: "BLUETOOTH DEVICE")
                VStack(spacing: 12) {
                    Image("tita_product_e57fb19").resizable().scaledToFit().frame(height: 175).padding(.horizontal, 18)
                    Text("TITA for Dashla").font(.system(size: 19, weight: .bold))
                    Text("通过 TITA 发射器读取车辆实时状态、轮胎数据与动态驾驶信息。") .font(.system(size: 12)).foregroundStyle(.secondary).multilineTextAlignment(.center).padding(.horizontal, 12)
                    HStack(spacing: 8) { Circle().fill(Color(hex: 0xF4B84D)).frame(width: 7, height: 7); Text(store.bluetoothState).font(.system(size: 11, weight: .semibold)).foregroundStyle(Color(hex: 0xF4B84D)) }.padding(.vertical, 8)
                    Button { store.scanTITA() } label: { HStack { if store.isScanning { ProgressView().tint(.black) }; Text(store.isScanning ? "正在搜索…" : "搜索 TITA 设备").font(.system(size: 13, weight: .bold)) }.frame(maxWidth: .infinity).padding(.vertical, 14).background(Color(hex: 0x42D7A2), in: RoundedRectangle(cornerRadius: 13)).foregroundStyle(Color.black) }.disabled(store.isScanning)
                }.padding(16).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 20))
                SectionHeading(title: "安装指南", subtitle: "HARDWARE SETUP")
                VStack(spacing: 10) { Image("tita_mount_1_9f6057c").resizable().scaledToFit().frame(height: 145); Text("将 TITA 发射器安装在车辆适配位置，并确认供电与指示灯状态。此版本仅提供界面与扫描流程，尚未实现专用 GATT 协议解析。") .font(.system(size: 11)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading) }.padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 16))
                HStack(spacing: 10) { Image("tita_x_dashla_ef5b7ea").resizable().scaledToFit().frame(width: 94, height: 72); VStack(alignment: .leading, spacing: 4) { Text("TITA × Dashla").font(.system(size: 13, weight: .bold)); Text("专为车辆数据可视化设计").font(.system(size: 10)).foregroundStyle(.secondary) }; Spacer() }.padding(12).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 16))
                Color.clear.frame(height: 90)
            }.padding(16)
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: VehicleStore
    @State private var useMetric = true
    @State private var alerts = true
    @State private var showTemp = true
    @State private var showTires = true
    @State private var showGForce = true
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                PageHeader(title: "设置", subtitle: "APP PREFERENCES")
                HStack(spacing: 12) { Image("dashla_dark_sm_7aea5db").resizable().scaledToFit().frame(width: 52, height: 52).clipShape(RoundedRectangle(cornerRadius: 13)); VStack(alignment: .leading, spacing: 3) { Text("Dashla for iOS").font(.system(size: 16, weight: .bold)); Text("原版 Dashla 2.9.2 UI 重建工程").font(.system(size: 10)).foregroundStyle(.secondary); Text("Build 0.9 · iOS 16+").font(.system(size: 9)).foregroundStyle(Color(hex: 0x42D7A2)) }; Spacer() }.padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 17))
                SettingsGroup(title: "数据与显示") {
                    ToggleRow(icon: "speedometer", title: "公制单位", subtitle: "km/h · km · bar", isOn: $useMetric)
                    ToggleRow(icon: "thermometer", title: "显示温度", subtitle: "电池、电机与环境温度", isOn: $showTemp)
                    ToggleRow(icon: "circle.grid.3x3", title: "显示轮胎信息", subtitle: "胎压与胎温", isOn: $showTires)
                    ToggleRow(icon: "waveform.path", title: "显示 G 值", subtitle: "动态加速度", isOn: $showGForce)
                }
                SettingsGroup(title: "提醒") { ToggleRow(icon: "bell.badge", title: "车辆状态提醒", subtitle: "连接后提示异常状态", isOn: $alerts) }
                SettingsGroup(title: "开发与调试") {
                    HStack { Label("模拟车辆数据", systemImage: "waveform.path.ecg").font(.system(size: 12, weight: .medium)); Spacer(); Toggle("", isOn: Binding(get: { store.demoEnabled }, set: { _ in store.toggleDemo() })).labelsHidden().tint(Color(hex: 0x42D7A2)) }
                    Divider().overlay(Color.white.opacity(0.06))
                    KeyValueRow(key: "数据接口", value: "VehicleDataSource")
                    KeyValueRow(key: "蓝牙协议", value: "待接入 / TITA GATT")
                    KeyValueRow(key: "最低系统", value: "iOS 16.0")
                }
                InfoBanner(text: "当前版本不控制车辆、不登录 Tesla 账户，也不调用 Tesla Fleet API。车辆数值为模拟数据。", icon: "exclamationmark.shield")
                Color.clear.frame(height: 90)
            }.padding(16)
        }
    }
}

// MARK: - Reusable UI
struct PageHeader: View {
    let title: String; let subtitle: String
    var body: some View { VStack(alignment: .leading, spacing: 4) { Text(title).font(.system(size: 29, weight: .bold, design: .rounded)); Text(subtitle).font(.system(size: 9, weight: .bold)).tracking(2).foregroundStyle(Color(hex: 0x42D7A2)) }.frame(maxWidth: .infinity, alignment: .leading).padding(.bottom, 3) }
}
struct SectionHeading: View {
    let title: String; let subtitle: String
    var body: some View { VStack(alignment: .leading, spacing: 3) { Text(title).font(.system(size: 14, weight: .bold)); Text(subtitle.uppercased()).font(.system(size: 8, weight: .semibold)).tracking(1.4).foregroundStyle(.secondary) }.frame(maxWidth: .infinity, alignment: .leading) }
}
struct MetricTile: View {
    let title: String; let value: String; let unit: String; let icon: String; let tint: Color; let foot: String
    var body: some View { VStack(alignment: .leading, spacing: 9) { Image(systemName: icon).font(.system(size: 16, weight: .semibold)).foregroundStyle(tint); Text(title).font(.system(size: 10)).foregroundStyle(.secondary); HStack(alignment: .firstTextBaseline, spacing: 3) { Text(value).font(.system(size: 27, weight: .semibold, design: .rounded).monospacedDigit()); Text(unit).font(.system(size: 10)).foregroundStyle(.secondary) }; Text(foot).font(.system(size: 9)).foregroundStyle(.secondary) }.frame(maxWidth: .infinity, alignment: .leading).padding(13).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 16)) }
}
struct StatusPill: View {
    let icon: String; let title: String; let active: Bool
    var body: some View { HStack(spacing: 5) { Image(systemName: icon); Text(title).lineLimit(1) }.font(.system(size: 9, weight: .semibold)).foregroundStyle(active ? Color(hex: 0x42D7A2) : Color(hex: 0xF4B84D)).frame(maxWidth: .infinity).padding(.vertical, 10).background(Color(hex: 0x151B24), in: Capsule()) }
}
struct TireValue: View {
    let position: String; let pressure: Double; let temp: Double
    var body: some View { VStack(spacing: 3) { Text(position).font(.system(size: 9)).foregroundStyle(.secondary); Text(String(format: "%.1f", pressure)).font(.system(size: 16, weight: .bold, design: .rounded).monospacedDigit()); Text("bar · \(Int(temp))°").font(.system(size: 8)).foregroundStyle(Color(hex: 0x42D7A2)) } }
}
struct DataColumn: View {
    let value: String; let unit: String; let title: String
    var body: some View { VStack(spacing: 4) { HStack(alignment: .firstTextBaseline, spacing: 3) { Text(value).font(.system(size: 20, weight: .bold, design: .rounded)); Text(unit).font(.system(size: 9)).foregroundStyle(.secondary) }; Text(title).font(.system(size: 9)).foregroundStyle(.secondary) }.frame(maxWidth: .infinity) }
}
struct SummaryCard: View {
    let title: String; let value: String; let unit: String; let icon: String
    var body: some View { VStack(alignment: .leading, spacing: 9) { Image(systemName: icon).foregroundStyle(Color(hex: 0x42D7A2)); Text(title).font(.system(size: 10)).foregroundStyle(.secondary); HStack(alignment: .firstTextBaseline, spacing: 4) { Text(value).font(.system(size: 26, weight: .bold, design: .rounded)); Text(unit).font(.system(size: 10)).foregroundStyle(.secondary) } }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 16)) }
}
struct TripRow: View {
    let date: String; let title: String; let route: String; let distance: String; let duration: String; let energy: String
    var body: some View { HStack(spacing: 11) { ZStack { Circle().fill(Color(hex: 0x42D7A2).opacity(0.12)).frame(width: 38, height: 38); Image(systemName: "car.side.fill").foregroundStyle(Color(hex: 0x42D7A2)) }; VStack(alignment: .leading, spacing: 4) { Text(title).font(.system(size: 12, weight: .bold)); Text(date + " · " + route).font(.system(size: 9)).foregroundStyle(.secondary); Text("\(duration)  ·  \(energy)").font(.system(size: 9)).foregroundStyle(.secondary) }; Spacer(); VStack(alignment: .trailing, spacing: 4) { Text(distance).font(.system(size: 13, weight: .bold)); Image(systemName: "chevron.right").font(.system(size: 9, weight: .bold)).foregroundStyle(.secondary) } }.padding(.vertical, 13) }
}
struct ActionTile: View {
    let icon: String; let title: String; let value: String; let tint: Color; let action: () -> Void
    var body: some View { Button(action: action) { VStack(alignment: .leading, spacing: 9) { Image(systemName: icon).font(.system(size: 18, weight: .semibold)).foregroundStyle(tint); Text(title).font(.system(size: 12, weight: .bold)).foregroundStyle(.white); Text(value).font(.system(size: 9)).foregroundStyle(.secondary) }.frame(maxWidth: .infinity, minHeight: 92, alignment: .leading).padding(13).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 15)) }.buttonStyle(.plain) }
}
struct KeyValueRow: View {
    let key: String; let value: String
    var body: some View { HStack { Text(key).font(.system(size: 11)).foregroundStyle(.secondary); Spacer(); Text(value).font(.system(size: 11, weight: .medium)).foregroundStyle(.white) }.padding(.vertical, 12).overlay(alignment: .bottom) { Rectangle().fill(Color.white.opacity(0.06)).frame(height: 0.5) } }
}
struct ToggleRow: View {
    let icon: String; let title: String; let subtitle: String; @Binding var isOn: Bool
    var body: some View { HStack(spacing: 10) { Image(systemName: icon).foregroundStyle(Color(hex: 0x42D7A2)).frame(width: 22); VStack(alignment: .leading, spacing: 3) { Text(title).font(.system(size: 11, weight: .medium)); Text(subtitle).font(.system(size: 9)).foregroundStyle(.secondary) }; Spacer(); Toggle("", isOn: $isOn).labelsHidden().tint(Color(hex: 0x42D7A2)) }.padding(.vertical, 8) }
}
struct SettingsGroup<Content: View>: View {
    let title: String; @ViewBuilder let content: Content
    var body: some View { VStack(alignment: .leading, spacing: 9) { Text(title).font(.system(size: 10, weight: .bold)).foregroundStyle(Color(hex: 0x42D7A2)).padding(.leading, 2); VStack(spacing: 2) { content }.padding(13).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 16)) } }
}
struct InfoBanner: View {
    let text: String; let icon: String
    var body: some View { HStack(alignment: .top, spacing: 9) { Image(systemName: icon).foregroundStyle(Color(hex: 0xF4B84D)); Text(text).font(.system(size: 10)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true) }.padding(12).frame(maxWidth: .infinity, alignment: .leading).background(Color(hex: 0xF4B84D).opacity(0.08), in: RoundedRectangle(cornerRadius: 13)) }
}

fileprivate enum DetailKind: String, Identifiable {
    case tires, temperature, battery, safety, map, tita, settings
    var id: String { rawValue }
    var title: String { switch self { case .tires: return "轮胎状态"; case .temperature: return "温度信息"; case .battery: return "电池与续航"; case .safety: return "安全状态"; case .map: return "地图与导航"; case .tita: return "TITA 连接"; case .settings: return "快捷操作" } }
}
struct DetailSheet: View {
    let kind: DetailKind
    @EnvironmentObject private var store: VehicleStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    switch kind {
                    case .tires:
                        Text("胎压单位：bar · 胎温单位：°C").font(.system(size: 11)).foregroundStyle(.secondary)
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                            TireDetailCard(position: "左前轮", pressure: store.data.frontLeftPressure, temp: store.data.frontLeftTemp)
                            TireDetailCard(position: "右前轮", pressure: store.data.frontRightPressure, temp: store.data.frontRightTemp)
                            TireDetailCard(position: "左后轮", pressure: store.data.rearLeftPressure, temp: store.data.rearLeftTemp)
                            TireDetailCard(position: "右后轮", pressure: store.data.rearRightPressure, temp: store.data.rearRightTemp)
                        }
                    case .temperature:
                        DetailMetric(title: "电池温度", value: "\(Int(store.data.batteryTemp))°C", icon: "battery.100", tint: Color(hex: 0x42D7A2))
                        DetailMetric(title: "电机温度", value: "\(Int(store.data.motorTemp))°C", icon: "gearshape.2", tint: Color(hex: 0x55B9FF))
                        DetailMetric(title: "环境温度", value: "\(Int(store.data.outsideTemp))°C", icon: "thermometer.medium", tint: Color(hex: 0xF4B84D))
                    case .battery:
                        DetailMetric(title: "当前电量", value: "\(Int(store.data.battery))%", icon: "battery.75percent", tint: Color(hex: 0x42D7A2))
                        DetailMetric(title: "预估剩余续航", value: "\(Int(store.data.range)) km", icon: "road.lanes", tint: Color(hex: 0x55B9FF))
                        InfoBanner(text: "续航数据仅用于 UI 预览，非车辆实时读数。", icon: "info.circle")
                    case .safety:
                        DetailMetric(title: "车门锁", value: store.data.isLocked ? "已锁定" : "未锁定", icon: "lock.fill", tint: Color(hex: 0x42D7A2))
                        DetailMetric(title: "安全带", value: store.data.seatbelt ? "已系好" : "未系", icon: "figure.seated.seatbelt", tint: Color(hex: 0x55B9FF))
                        DetailMetric(title: "驻车制动", value: store.data.parkingBrake ? "已启用" : "未启用", icon: "parkingsign.circle", tint: Color(hex: 0xF4B84D))
                    case .map:
                        RoundedRectangle(cornerRadius: 18).fill(Color(hex: 0x18232C)).frame(height: 240).overlay(VStack(spacing: 10) { Image(systemName: "map.fill").font(.system(size: 35)).foregroundStyle(Color(hex: 0x42D7A2)); Text("地图预览").font(.system(size: 16, weight: .bold)); Text("接入定位与路线服务后显示实时位置").font(.system(size: 10)).foregroundStyle(.secondary) })
                        InfoBanner(text: "此版本未启用后台定位、路线规划或测速摄像头服务。", icon: "location.slash")
                    case .tita:
                        Image("tita_product_e57fb19").resizable().scaledToFit().frame(height: 180)
                        Text("TITA 当前未连接").font(.system(size: 16, weight: .bold))
                        Button { store.scanTITA() } label: { Text(store.isScanning ? "搜索中…" : "搜索设备").font(.system(size: 13, weight: .bold)).frame(maxWidth: .infinity).padding(14).background(Color(hex: 0x42D7A2), in: RoundedRectangle(cornerRadius: 12)).foregroundStyle(.black) }.disabled(store.isScanning)
                        InfoBanner(text: "目前已搭建设备页与扫描交互。专用 TITA GATT 服务 UUID、特征值与数据帧解析尚未完成。", icon: "info.circle")
                    case .settings:
                        Text("通过底部设置页面管理单位、数据显示和模拟模式。") .font(.system(size: 12)).foregroundStyle(.secondary)
                    }
                }.padding(16)
            }
            .background(Color(hex: 0x080B10))
            .navigationTitle(kind.title).navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { dismiss() }.foregroundStyle(Color(hex: 0x42D7A2)) } }
        }.preferredColorScheme(.dark)
    }
}
struct TireDetailCard: View {
    let position: String; let pressure: Double; let temp: Double
    var body: some View { VStack(alignment: .leading, spacing: 8) { Text(position).font(.system(size: 11)).foregroundStyle(.secondary); Text(String(format: "%.1f bar", pressure)).font(.system(size: 22, weight: .bold, design: .rounded)); HStack { Image(systemName: "thermometer"); Text("\(Int(temp))°C") }.font(.system(size: 10)).foregroundStyle(Color(hex: 0x42D7A2)) }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 15)) }
}
struct DetailMetric: View {
    let title: String; let value: String; let icon: String; let tint: Color
    var body: some View { HStack(spacing: 12) { Image(systemName: icon).font(.system(size: 19)).foregroundStyle(tint).frame(width: 36, height: 36).background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 10)); Text(title).font(.system(size: 12)); Spacer(); Text(value).font(.system(size: 15, weight: .bold, design: .rounded)) }.padding(14).background(Color(hex: 0x151B24), in: RoundedRectangle(cornerRadius: 15)) }
}

extension Color {
    init(hex: UInt, opacity: Double = 1) {
        self.init(.sRGB, red: Double((hex >> 16) & 0xff) / 255, green: Double((hex >> 8) & 0xff) / 255, blue: Double(hex & 0xff) / 255, opacity: opacity)
    }
}
