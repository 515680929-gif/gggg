import SwiftUI

/// 右侧音乐面板（对齐 Dashla）：
/// - 音乐页：专辑封面 + 歌名 + 歌手 + 来源标识（Apple Music / Spotify）；
/// - 歌词页：垂直滚动歌词列表，当前行高亮放大、上下渐暗，自动滚到当前行。
/// 双击在两页间切换；面板切换器的「歌词」页直接进入歌词。
struct MusicPanelView: View {
    let nowPlaying: NowPlayingService
    var compact: Bool = false
    var startWithLyrics: Bool = false
    @State private var showLyrics = false

    private var panelMaxWidth: CGFloat { compact ? 210 : 250 }
    private var panelMinHeight: CGFloat { compact ? 160 : 240 }
    private var iconSize: CGFloat { compact ? 92 : 150 }

    var body: some View {
        ZStack {
            if showLyrics || startWithLyrics {
                lyricsView
            } else {
                musicView
            }
        }
        .frame(maxWidth: panelMaxWidth, minHeight: panelMinHeight)
        .contentShape(Rectangle())
        .onTapGesture(count: 2) {
            withAnimation(.easeInOut(duration: 0.25)) { showLyrics.toggle() }
        }
    }

    // MARK: - 歌曲信息卡
    private var musicView: some View {
        VStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(colors: [Color(white: 0.20), Color(white: 0.08)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                // 专辑封面（系统占位；真机若无封面显示音符）
                Image(systemName: "music.note")
                    .font(.system(size: iconSize * 0.36, weight: .light))
                    .foregroundStyle(DashboardTheme.secondaryText.opacity(0.8))
                RoundedRectangle(cornerRadius: 16)
                    .stroke(DashboardTheme.ringTrack, lineWidth: 1)
            }
            .frame(width: iconSize, height: iconSize)
            .shadow(color: .black.opacity(0.5), radius: 10, y: 4)

            if let title = nowPlaying.title {
                Text(title)
                    .font(.system(size: compact ? 15 : 18, weight: .semibold))
                    .foregroundStyle(DashboardTheme.primaryText)
                    .lineLimit(1)
                if let artist = nowPlaying.artist {
                    Text(artist)
                        .font(.system(size: compact ? 12 : 14))
                        .foregroundStyle(DashboardTheme.secondaryText)
                        .lineLimit(1)
                }
                // 来源标识（仿 Dashla 右上角 ▶ 标）
                HStack(spacing: 4) {
                    Image(systemName: "music.note")
                        .font(.system(size: 10))
                    Text("Apple Music")
                        .font(.system(size: 11, weight: .medium))
                }
                .foregroundStyle(DashboardTheme.secondaryText.opacity(0.75))
            } else {
                Text("未在播放")
                    .font(.system(size: 16))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }
        }
    }

    // MARK: - 垂直滚动歌词
    private var lyricsView: some View {
        let lyrics = nowPlaying.lyrics
        let lines = lyrics.lines
        let current = lyrics.currentIndex

        return Group {
            if lines.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "text.badge.xmark")
                        .font(.system(size: 28))
                        .foregroundStyle(DashboardTheme.secondaryText)
                    Text(nowPlaying.title.map { "「\($0)」暂无歌词" } ?? "未在播放")
                        .font(.system(size: 14))
                        .foregroundStyle(DashboardTheme.secondaryText)
                }
                .frame(maxWidth: .infinity, minHeight: panelMinHeight)
            } else {
                ScrollViewReader { proxy in
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: compact ? 8 : 12) {
                            ForEach(lines.indices, id: \.self) { i in
                                Text(lines[i].text)
                                    .font(.system(size: i == current
                                                  ? (compact ? 18 : 22)
                                                  : (compact ? 13 : 15),
                                                  weight: i == current ? .bold : .medium))
                                    .foregroundStyle(
                                        i == current
                                            ? DashboardTheme.primaryText
                                            : DashboardTheme.secondaryText.opacity(
                                                i < current ? 0.35 : 0.55)
                                    )
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .id(i)
                                    .animation(.easeInOut(duration: 0.25), value: current)
                            }
                            .padding(.vertical, panelMinHeight / 2 - 20)
                        }
                    }
                    .frame(maxWidth: .infinity, minHeight: panelMinHeight)
                    .mask(
                        LinearGradient(
                            gradient: Gradient(stops: [
                                .init(color: .clear, location: 0),
                                .init(color: .white, location: 0.25),
                                .init(color: .white, location: 0.75),
                                .init(color: .clear, location: 1)
                            ]),
                            startPoint: .top, endPoint: .bottom
                        )
                    )
                    .onChange(of: current) { _, new in
                        if new >= 0 {
                            withAnimation(.easeInOut(duration: 0.35)) {
                                proxy.scrollTo(new, anchor: .center)
                            }
                        }
                    }
                    .onAppear {
                        if current >= 0 {
                            proxy.scrollTo(current, anchor: .center)
                        }
                    }
                }
            }
        }
    }
}
