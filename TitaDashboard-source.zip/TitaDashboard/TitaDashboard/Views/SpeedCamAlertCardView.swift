import SwiftUI

/// 测速提醒卡片：距离倒数浮窗 + 拍摄方向 + 当前车速；超速时变红并闪动边框。
struct SpeedCamAlertCardView: View {
    let alert: SpeedCamAlert

    @State private var flashing = false
    private let flashTimer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack(spacing: 14) {
            // 类型图标
            Image(systemName: iconName)
                .font(.system(size: 26))
                .foregroundStyle(alert.isOverspeed ? .white : DashboardTheme.accentOrange)

            // 主信息：类型 + 限速
            VStack(alignment: .leading, spacing: 2) {
                HStack(spacing: 6) {
                    Text(alert.type.rawValue)
                        .font(.system(size: 15, weight: .semibold))
                    if let sec = alert.sectionLengthKm {
                        Text(String(format: "区间 %.1fkm", sec))
                            .font(.system(size: 11))
                            .opacity(0.8)
                    }
                }
                Text("限速 \(alert.speedLimit)")
                    .font(DashboardTheme.monoDigit(size: 14))
                    .opacity(0.85)
            }

            Spacer()

            // 拍摄方向箭头（ Dashla：测速点方向可辨识）
            if let dir = alert.direction {
                Image(systemName: "location.north.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(.white.opacity(0.8))
                    .rotationEffect(.degrees(dir))
                    .help("拍摄方向 \(Int(dir))°")
            }

            // 距离倒数浮窗（大字）
            VStack(spacing: 0) {
                Text("\(alert.distanceMeters)")
                    .font(DashboardTheme.monoDigit(size: 30, weight: .bold))
                Text("米")
                    .font(.system(size: 11))
                    .opacity(0.8)
            }
            .frame(minWidth: 56)

            // 当前车速（超速时红色高亮）
            VStack(spacing: 0) {
                Text(String(format: "%.0f", alert.currentSpeed))
                    .font(DashboardTheme.monoDigit(size: 22, weight: .bold))
                    .foregroundStyle(alert.isOverspeed ? .yellow : .white)
                Text("km/h")
                    .font(.system(size: 10))
                    .opacity(0.8)
            }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(alert.isOverspeed
                      ? Color.red.opacity(0.85)
                      : Color(white: 0.12).opacity(0.92))
        )
        // 超速时边框闪动
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(
                    alert.isOverspeed
                        ? Color.white.opacity(flashing ? 0.9 : 0.15)
                        : Color.white.opacity(0.15),
                    lineWidth: alert.isOverspeed ? 2.5 : 1
                )
        )
        .shadow(color: alert.isOverspeed ? .red.opacity(flashing ? 0.6 : 0.1) : .clear,
                radius: 10)
        .onReceive(flashTimer) { _ in
            if alert.isOverspeed { flashing.toggle() }
        }
        .transition(.move(edge: .top).combined(with: .opacity))
    }

    private var iconName: String {
        switch alert.type {
        case .fixed, .mobile: return "camera.fill"
        case .tech:           return "antenna.radiowaves.left.and.right"
        case .section:        return "road.lanes"
        }
    }
}
