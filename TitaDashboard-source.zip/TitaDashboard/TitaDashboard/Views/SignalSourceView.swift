import SwiftUI
import CoreLocation

/// 信号来源诊断卡（对齐 Dashla「訊號來源」）：Tesla / GPS / TITA 三路连接状态。
struct SignalSourceView: View {
    @Environment(TitaConnectionManager.self) private var connectionManager
    @Environment(VehicleState.self) private var vehicleState
    let locationService: LocationService

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("信号来源", systemImage: "antenna.radiowaves.left.and.right")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(DashboardTheme.primaryText)

            sourceRow(name: "Tesla", detail: teslaDetail, connected: teslaOK,
                      icon: "car.fill")
            sourceRow(name: "GPS", detail: gpsDetail, connected: gpsOK,
                      icon: "location.fill")
            sourceRow(name: "TITA", detail: titaDetail, connected: titaOK,
                      icon: "waveform.path.ecg")
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 14).fill(Color(white: 0.07)))
        .overlay(RoundedRectangle(cornerRadius: 14)
            .stroke(DashboardTheme.ringTrack, lineWidth: 1))
    }

    private func sourceRow(name: String, detail: String, connected: Bool,
                           icon: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(connected ? DashboardTheme.signalGreen
                                           : DashboardTheme.secondaryText)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 1) {
                Text(name)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(DashboardTheme.primaryText)
                Text(detail)
                    .font(.system(size: 11))
                    .foregroundStyle(DashboardTheme.secondaryText)
                    .lineLimit(1)
            }
            Spacer()
            HStack(spacing: 5) {
                Circle()
                    .fill(connected ? DashboardTheme.signalGreen : DashboardTheme.secondaryText)
                    .frame(width: 8, height: 8)
                    .shadow(color: connected ? DashboardTheme.signalGreen : .clear, radius: 4)
                Text(connected ? "已连" : "未连")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(connected ? DashboardTheme.signalGreen
                                               : DashboardTheme.secondaryText)
            }
        }
    }

    // MARK: - 三路判定
    private var teslaOK: Bool {
        // TITA 有车速/档位数据，说明车辆 CAN 总线已接通
        vehicleState.speedKmh != nil || vehicleState.gear != nil ||
        vehicleState.batteryPercent != nil
    }

    private var teslaDetail: String {
        if let speed = vehicleState.speedKmh {
            return String(format: "车速 %.0f km/h", speed)
        }
        return "等待车辆数据"

    }

    private var gpsOK: Bool {
        locationService.authorization == .authorizedWhenInUse ||
        locationService.authorization == .authorizedAlways
    }

    private var gpsDetail: String {
        guard let coord = locationService.coordinate else { return "定位中…" }
        return String(format: "%.4f, %.4f", coord.latitude, coord.longitude)
    }

    private var titaOK: Bool {
        if case .connected = connectionManager.status { return true }
        return false
    }

    private var titaDetail: String {
        switch connectionManager.status {
        case .connected:  return "BLE 已连接"
        case .scanning:   return "扫描中…"
        case .connecting: return "连接中…"
        case .failed(let msg): return msg
        case .disconnected: return "未连接"
        }
    }
}
