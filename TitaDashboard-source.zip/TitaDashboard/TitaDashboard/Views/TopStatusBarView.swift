import SwiftUI

/// 顶部状态栏：时间、车内外温度、连接状态、设置入口
struct TopStatusBarView: View {
    @Environment(VehicleState.self) private var vehicleState
    @Environment(TitaConnectionManager.self) private var connectionManager

    var onOpenSettings: () -> Void
    var onOpenConnection: () -> Void
    /// 竖屏紧凑模式：缩小字号与间距，禁止温度文本换行
    var compact: Bool = false

    @State private var now = Date()
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack(spacing: compact ? 10 : 18) {
            // 时间
            Text(now, format: .dateTime.hour().minute())
                .font(DashboardTheme.monoDigit(size: compact ? 17 : 22, weight: .bold))
                .foregroundStyle(DashboardTheme.primaryText)
                .fixedSize()

            // 车外温度
            Label(tempText(vehicleState.outsideTempC), systemImage: "cloud.sun")
                .font(.system(size: compact ? 12 : 15))
                .foregroundStyle(DashboardTheme.secondaryText)
                .lineLimit(1)
                .fixedSize()

            // 车内温度
            Label(tempText(vehicleState.insideTempC), systemImage: "car.side")
                .font(.system(size: compact ? 12 : 15))
                .foregroundStyle(DashboardTheme.secondaryText)
                .lineLimit(1)
                .fixedSize()

            // 连接状态点
            Circle()
                .fill(statusColor)
                .frame(width: 10, height: 10)

            Spacer()

            // AP 自动驾驶
            if vehicleState.autopilotActive {
                Image(systemName: "steeringwheel")
                    .foregroundStyle(.blue)
            }

            // 大灯 / 双闪（TITA 专属）
            if vehicleState.headlightsOn {
                Image(systemName: "lightbulb.fill")
                    .foregroundStyle(Color.yellow.opacity(0.9))
                    .help("大灯已开")
            }
            if vehicleState.hazardOn {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundStyle(DashboardTheme.accentOrange)
                    .help("双闪警示")
            }

            // 未系安全带警告（TITA 专属，行驶中未系才提示）
            if vehicleState.seatbeltFastened == false,
               (vehicleState.speedKmh ?? 0) > 5 {
                Image(systemName: "seat.belt")
                    .foregroundStyle(DashboardTheme.accentRed)
                    .help("请系安全带")
            }

            // 车门未关（TITA 专属）
            if vehicleState.doorAjar {
                Image(systemName: "door.left.hand.open")
                    .foregroundStyle(DashboardTheme.accentRed)
                    .help("车门未关")
            }

            // 配对入口
            Button(action: onOpenConnection) {
                Image(systemName: "antenna.radiowaves.left.and.right")
                    .font(.system(size: 18))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }

            // 设置入口
            Button(action: onOpenSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18))
                    .foregroundStyle(DashboardTheme.secondaryText)
            }
        }
        .padding(.horizontal, compact ? 16 : 24)
        .padding(.top, 10)
        .onReceive(ticker) { now = $0 }
    }

    private var statusColor: Color {
        switch connectionManager.status {
        case .connected:    return DashboardTheme.accentGreen
        case .connecting:   return DashboardTheme.accentOrange
        default:            return DashboardTheme.placeholder
        }
    }

    private func tempText(_ c: Double?) -> String {
        guard let c else { return "--°C" }
        return String(format: "%.0f°C", c)
    }
}
