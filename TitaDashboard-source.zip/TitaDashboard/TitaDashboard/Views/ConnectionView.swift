import SwiftUI

/// 发射器配对引导页：BLE 扫描连接 + 原始数据日志（协议联调用）
struct ConnectionView: View {
    @Environment(TitaConnectionManager.self) private var connectionManager
    @State private var copied = false

    var onBack: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    stepOne
                    stepTwo
                    stepThree
                    debugSection
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("发射器模式配对")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: onBack) {
                        Image(systemName: "chevron.left")
                    }
                }
            }
        }
        .preferredColorScheme(.light)
    }

    // MARK: - 第一步：OTA 固件（Wi-Fi 网页）
    private var stepOne: some View {
        VStack(alignment: .leading, spacing: 12) {
            stepHeader("第一步：OTA 发射器到 1.66 版本以上")

            VStack(alignment: .leading, spacing: 8) {
                Text("手机 Wi-Fi 连接 **TITA_SENDER**（密码 TSLA1234），点击下面链接把发射器 OTA 到 1.66 以上：")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Link("http://m.hitita.cc/sender/",
                     destination: URL(string: "http://m.hitita.cc/sender/")!)
                    .font(.subheadline)
                Text("若页面无法打开，浏览器直接访问 4.3.2.1")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .cardStyle()
        }
    }

    // MARK: - 第二步：开启第二路协议
    private var stepTwo: some View {
        VStack(alignment: .leading, spacing: 12) {
            stepHeader("第二步：开启第二路协议（BLE）")

            VStack(alignment: .leading, spacing: 8) {
                Text("在发射器 OTA 网页的「自定义设置」中：")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Label("找到「第二路协议 / Second Protocol」，点击「开启」", systemImage: "1.circle.fill")
                Label("此协议通过蓝牙（BLE）广播，最多 5 个连接", systemImage: "2.circle.fill")
                Label("保存后发射器会自动重启", systemImage: "3.circle.fill")
                    .font(.subheadline)
            }
            .font(.subheadline)
            .cardStyle()
        }
    }

    // MARK: - 第三步：BLE 连接测试
    private var stepThree: some View {
        VStack(alignment: .leading, spacing: 12) {
            stepHeader("第三步：蓝牙连接发射器")

            VStack(spacing: 14) {
                Button {
                    if connectionManager.status == .connected {
                        connectionManager.disconnect()
                    } else {
                        connectionManager.connect()
                    }
                } label: {
                    Text(buttonTitle)
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(buttonColor.gradient)
                        )
                }

                statusBadge

                if !connectionManager.discoveredPeripherals.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("附近设备")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        ForEach(connectionManager.discoveredPeripherals, id: \.name) { dev in
                            HStack {
                                Image(systemName: "wave.3.right")
                                    .foregroundStyle(.blue)
                                Text(dev.name)
                                    .font(.subheadline)
                                Spacer()
                                Text("\(dev.rssi) dBm")
                                    .font(.caption.monospacedDigit())
                                    .foregroundStyle(.secondary)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 4)
                }
            }
            .cardStyle()
        }
    }

    private var buttonTitle: String {
        switch connectionManager.status {
        case .connected:  return "断开连接"
        case .scanning:   return "正在扫描…"
        case .connecting: return "正在连接…"
        default:          return "点击测试（扫描 TITA_BLE）"
        }
    }

    private var buttonColor: Color {
        switch connectionManager.status {
        case .connected:  return .gray
        case .scanning, .connecting: return .orange
        default:          return .orange
        }
    }

    private var statusBadge: some View {
        HStack(spacing: 8) {
            Image(systemName: statusIcon)
                .foregroundStyle(statusColor)
            Text(connectionManager.status.displayText)
                .font(.subheadline)
                .foregroundStyle(statusColor)
            Spacer()
            if let last = connectionManager.lastFrameTime {
                Text("最近数据 \(last, format: .dateTime.hour().minute().second())")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    // MARK: - 原始数据日志（协议联调用）
    private var debugSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                stepHeader("原始数据日志（协议联调用）")
                Spacer()
                Button {
                    UIPasteboard.general.string = connectionManager.debugLog.joined(separator: "\n")
                    copied = true
                    Task {
                        try? await Task.sleep(for: .seconds(1.5))
                        copied = false
                    }
                } label: {
                    Label(copied ? "已复制" : "复制全部",
                          systemImage: copied ? "checkmark.circle.fill" : "doc.on.doc")
                        .font(.caption)
                        .foregroundStyle(copied ? .green : .blue)
                }
                .disabled(connectionManager.debugLog.isEmpty)
            }

            Text("连接后此处会显示发射器发来的原始字节（hex）与文本。点右上角「复制全部」后发我，用于确认字段映射。")
                .font(.caption)
                .foregroundStyle(.secondary)

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(connectionManager.debugLog.enumerated().reversed()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(10)
            }
            .frame(height: 220)
            .background(Color(uiColor: .secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }

    // MARK: - 小组件
    private func stepHeader(_ text: String) -> some View {
        Text(text)
            .font(.headline)
            .foregroundStyle(.secondary)
    }

    private var statusIcon: String {
        switch connectionManager.status {
        case .connected:   return "checkmark.circle.fill"
        case .scanning:    return "magnifyingglass.circle.fill"
        case .connecting:  return "arrow.triangle.2.circlepath"
        case .failed:      return "xmark.circle.fill"
        case .disconnected: return "circle"
        }
    }

    private var statusColor: Color {
        switch connectionManager.status {
        case .connected:   return .green
        case .scanning, .connecting: return .orange
        case .failed:      return .red
        case .disconnected: return .secondary
        }
    }
}

private extension View {
    func cardStyle() -> some View {
        self
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}
