import SwiftUI

/// 导航详情面板：叠加在地图区。
/// 显示 ETA、剩余距离、到达预计电量、下一步转向、出口编号、当前路段名。
/// 数据来自 TITA / BLE 推送；无数据时显示占位，不崩溃。
struct NavInfoPanelView: View {
    @Environment(VehicleState.self) private var vehicleState

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // 顶部：路段名 + 出口
            HStack(spacing: 8) {
                Image(systemName: "road.lanes")
                    .font(.system(size: 16))
                    .foregroundStyle(DashboardTheme.accentGreen)
                Text(vehicleState.navRoad ?? "当前路段 --")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(DashboardTheme.primaryText)
                    .lineLimit(1)
                if let exit = vehicleState.navExit {
                    Text("出口 \(exit)")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Capsule().fill(DashboardTheme.accentOrange))
                }
                Spacer(minLength: 0)
            }

            // 下一步转向（放大引导）
            HStack(spacing: 8) {
                Image(systemName: "arrow.turn.up.right")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 34, height: 34)
                    .background(RoundedRectangle(cornerRadius: 9)
                        .fill(DashboardTheme.accentGreen.opacity(0.9)))
                Text(vehicleState.navTurn ?? "暂无导航指令")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(DashboardTheme.primaryText)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Divider().background(DashboardTheme.ringTrack)

            // 底部三列：剩余距离 / ETA / 到达电量
            HStack(spacing: 0) {
                navMetric(title: "剩余", value: remainText, systemImage: "map")
                navMetric(title: "预计到达", value: vehicleState.navEta ?? "--:--", systemImage: "clock")
                navMetric(title: "到达电量", value: arrivalSocText, systemImage: "battery.50")
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(white: 0.08).opacity(0.92))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(DashboardTheme.ringTrack, lineWidth: 1)
        )
    }

    private func navMetric(title: String, value: String, systemImage: String) -> some View {
        VStack(spacing: 4) {
            Label(title, systemImage: systemImage)
                .font(.system(size: 11))
                .foregroundStyle(DashboardTheme.secondaryText)
            Text(value)
                .font(DashboardTheme.monoDigit(size: 18, weight: .bold))
                .foregroundStyle(DashboardTheme.primaryText)
        }
        .frame(maxWidth: .infinity)
    }

    private var remainText: String {
        guard let km = vehicleState.navRemainKm else { return "-- km" }
        return String(format: "%.1f km", km)
    }

    private var arrivalSocText: String {
        guard let soc = vehicleState.navArrivalSoc else { return "--%" }
        return "\(soc)%"
    }
}
