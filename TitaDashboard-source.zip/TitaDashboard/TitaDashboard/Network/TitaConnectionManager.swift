import Foundation
import CoreBluetooth
import Observation

/// 扫描到的 BLE 设备
struct DiscoveredDevice: Identifiable {
    let name: String
    let rssi: Int
    var id: String { name }
}

enum ConnectionStatus: Equatable {
    case disconnected
    case scanning
    case connecting
    case connected
    case failed(String)

    var displayText: String {
        switch self {
        case .disconnected: return "未连接"
        case .scanning:     return "扫描中…"
        case .connecting:   return "连接中…"
        case .connected:    return "已连接"
        case .failed(let m): return "连接失败：\(m)"
        }
    }
}

/// TITA 发射器连接管理器（BLE GATT）
///
/// 固件逆向结论（ESP32-C3，NimBLE Server）：
/// - 广播名：TITA_BLE（第二路协议 = Second Protocol = BLE，最多 5 个连接）
/// - Service UUID:       4fafc201-1fb5-459e-8fcc-c5c9c331914b
/// - Characteristic UUID: beb5483e-36e1-4688-b7f5-ea07361b26a8（Notify）
///
/// 注意：Wi-Fi 热点 TITA_SENDER / 4.3.2.1 仅用于 OTA 与网页配置，
/// 实时车辆数据走的是 BLE，不是 WebSocket。
@Observable
final class TitaConnectionManager: NSObject {
    static let serviceUUID = CBUUID(string: "4fafc201-1fb5-459e-8fcc-c5c9c331914b")
    static let characteristicUUID = CBUUID(string: "beb5483e-36e1-4688-b7f5-ea07361b26a8")
    static let advertiseName = "TITA_BLE"

    private(set) var status: ConnectionStatus = .disconnected
    private(set) var lastFrameTime: Date? = nil
    /// 最近收到的原始帧（hex + utf8 文本），用于配对页调试
    private(set) var debugLog: [String] = []
    /// 扫描到的 TITA 设备
    private(set) var discoveredPeripherals: [DiscoveredDevice] = []

    var autoReconnect = true

    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var notifyCharacteristic: CBCharacteristic?
    private var reconnectTask: Task<Void, Never>?
    private var heartbeatTask: Task<Void, Never>?
    private let vehicleState: VehicleState

    init(vehicleState: VehicleState) {
        self.vehicleState = vehicleState
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
    }

    // MARK: - 连接控制

    /// 扫描并连接 TITA_BLE
    func connect() {
        guard let central else { return }
        switch central.state {
        case .poweredOn:
            startScan()
        case .unauthorized:
            status = .failed("蓝牙权限被拒绝，请在设置中允许")
        case .poweredOff:
            status = .failed("蓝牙未开启")
        case .unsupported:
            status = .failed("此设备不支持蓝牙")
        default:
            status = .connecting // 等待系统蓝牙就绪，centralManagerDidUpdateState 会继续
        }
    }

    func disconnect(clearState: Bool = true) {
        reconnectTask?.cancel(); reconnectTask = nil
        heartbeatTask?.cancel(); heartbeatTask = nil
        central?.stopScan()
        if let peripheral {
            central?.cancelPeripheralConnection(peripheral)
        }
        peripheral = nil
        notifyCharacteristic = nil
        status = .disconnected
        if clearState {
            Task { @MainActor in vehicleState.clearRealtime() }
        }
    }

    private func startScan() {
        central?.stopScan()
        discoveredPeripherals = []
        status = .scanning
        log("开始扫描 BLE 设备（广播名 \(Self.advertiseName)）…")
        central?.scanForPeripherals(
            withServices: [Self.serviceUUID],
            options: [CBCentralManagerScanOptionAllowDuplicatesKey: true]
        )
    }

    // MARK: - 数据接收

    private func handleData(_ data: Data) {
        lastFrameTime = Date()

        // 原始帧：hex + 可读文本（供配对页确认真实帧格式）
        let hex = data.map { String(format: "%02x", $0) }.joined(separator: " ")
        if let text = String(data: data, encoding: .utf8), !text.isEmpty {
            log("RECV \(data.count)B \(hex)")
            log("     TEXT: \(text)")
        } else {
            log("RECV \(data.count)B \(hex)")
        }

        // 尝试解析：优先 JSON 文本，其次二进制
        var frame: TitaFrame?
        if let text = String(data: data, encoding: .utf8),
           let parsed = TitaFrameParser.parse(text: text) {
            frame = parsed
        } else if let parsed = TitaFrameParser.parse(binary: data) {
            frame = parsed
        }

        if let frame {
            vehicleState.apply(frame)
        }
    }

    // MARK: - 心跳 & 自动重连

    private func startHeartbeat() {
        heartbeatTask?.cancel()
        heartbeatTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(5))
                guard let self, !Task.isCancelled else { return }
                // BLE 空闲时可能无数据，10 秒无帧则重连（发射器有广播接收，不占用连接数）
                if let last = await MainActor.run(body: { self.lastFrameTime }),
                   Date().timeIntervalSince(last) > 10 {
                    await MainActor.run {
                        self.log("数据超时，触发重连")
                        self.connect()
                    }
                    return
                }
            }
        }
    }

    private func scheduleReconnect() {
        guard autoReconnect, reconnectTask == nil else { return }
        reconnectTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(3))
            guard let self, !Task.isCancelled else { return }
            await MainActor.run { self.reconnectTask = nil; self.connect() }
        }
    }

    // MARK: - 调试日志

    private func log(_ message: String, maxKeep: Int = 200) {
        let stamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        debugLog.append("[\(stamp)] \(message)")
        if debugLog.count > maxKeep { debugLog.removeFirst(debugLog.count - maxKeep) }
    }
}

// MARK: - CBCentralManagerDelegate
extension TitaConnectionManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            if status == .connecting { startScan() }
        case .unauthorized:
            status = .failed("蓝牙权限被拒绝，请在设置中允许")
            log("蓝牙权限被拒绝")
        case .poweredOff:
            status = .failed("蓝牙未开启")
            log("蓝牙未开启")
        case .unsupported:
            status = .failed("此设备不支持蓝牙")
        default:
            break
        }
    }

    func centralManager(_ central: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any],
                        rssi RSSI: NSNumber) {
        let name = peripheral.name ?? (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? "未知设备"
        let entry = DiscoveredDevice(name: name, rssi: RSSI.intValue)
        if !discoveredPeripherals.contains(where: { $0.name == name }) {
            discoveredPeripherals.append(entry)
            log("发现设备：\(name) (RSSI \(RSSI.intValue))")
        }
        // 已用 withServices 过滤（只广播 TITA Service 的设备才会被发现），发现即连接。
        // 优先连接名字含 TITA 的，否则连接首个发现的设备。
        if self.peripheral == nil {
            log("连接设备 \(name) …")
            central.stopScan()
            self.peripheral = peripheral
            peripheral.delegate = self
            status = .connecting
            central.connect(peripheral, options: nil)
        }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        log("BLE 已连接，发现服务…")
        status = .connecting
        peripheral.discoverServices([Self.serviceUUID])
    }

    func centralManager(_ central: CBCentralManager,
                        didFailToConnect peripheral: CBPeripheral,
                        error: Error?) {
        status = .failed(error?.localizedDescription ?? "连接失败")
        log("连接失败：\(error?.localizedDescription ?? "未知")")
        scheduleReconnect()
    }

    func centralManager(_ central: CBCentralManager,
                        didDisconnectPeripheral peripheral: CBPeripheral,
                        error: Error?) {
        log("连接断开：\(error?.localizedDescription ?? "主动断开")")
        if error != nil { scheduleReconnect() } else { status = .disconnected }
    }
}

// MARK: - CBPeripheralDelegate
extension TitaConnectionManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error {
            status = .failed(error.localizedDescription)
            log("发现服务失败：\(error.localizedDescription)")
            return
        }
        guard let service = peripheral.services?.first(where: { $0.uuid == Self.serviceUUID }) else {
            status = .failed("未找到 TITA 数据服务")
            log("未找到 Service \(Self.serviceUUID.uuidString)")
            return
        }
        log("找到 Service，发现特征…")
        peripheral.discoverCharacteristics([Self.characteristicUUID], for: service)
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didDiscoverCharacteristicsFor service: CBService,
                    error: Error?) {
        if let error {
            status = .failed(error.localizedDescription)
            log("发现特征失败：\(error.localizedDescription)")
            return
        }
        guard let characteristic = service.characteristics?
            .first(where: { $0.uuid == Self.characteristicUUID }) else {
            status = .failed("未找到 TITA 数据特征")
            log("未找到 Characteristic \(Self.characteristicUUID.uuidString)")
            return
        }
        notifyCharacteristic = characteristic
        log("找到 Notify 特征，订阅中…")
        peripheral.setNotifyValue(true, for: characteristic)
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didUpdateNotificationStateFor characteristic: CBCharacteristic,
                    error: Error?) {
        if let error {
            status = .failed(error.localizedDescription)
            log("订阅失败：\(error.localizedDescription)")
            return
        }
        guard characteristic.isNotifying else {
            status = .failed("订阅未生效")
            return
        }
        status = .connected
        log("已订阅数据，等待车辆帧…")
        startHeartbeat()
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didUpdateValueFor characteristic: CBCharacteristic,
                    error: Error?) {
        if let error {
            log("接收错误：\(error.localizedDescription)")
            return
        }
        if let data = characteristic.value {
            handleData(data)
        }
    }
}
