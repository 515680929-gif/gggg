import Foundation

// MARK: - 字段映射（★ 真机联调时按发射器实际推送的 key 修改这里即可）
/// TITA 官方未公开第二路协议字段文档，此处 key 为常见命名约定，
/// 请通过「连接测试」页的原始日志确认实际字段名后在此集中替换。
enum FieldKey {
    static let speed        = "speed"        // 车速 km/h
    static let gear         = "gear"         // 档位 "P"/"R"/"N"/"D" 或数字 0-3
    static let battery      = "soc"          // 电量 %
    static let range        = "range"        // 续航 km
    static let odometer     = "odo"          // 总里程 km
    static let outsideTemp  = "temp_out"     // 车外温度 ℃
    static let insideTemp   = "temp_in"      // 车内温度 ℃
    static let power        = "power"        // 功率 kW
    static let leftSignal   = "turn_l"
    static let rightSignal  = "turn_r"
    static let autopilot    = "ap"
    static let blindLeft    = "bs_l"
    static let blindRight   = "bs_r"
    static let tirePressure = "tpms"         // [FL, FR, RL, RR] bar
    static let brake        = "brake"        // 刹车踏板 0/1
    static let speedLimit   = "speed_limit"  // 道路限速 km/h（TITA 专属信号）
    static let seatbelt     = "seatbelt"     // 主驾安全带 1=已系
    static let trafficLight = "traffic_light"// 红绿灯状态 "red"/"green"/"none"
    static let doorAjar     = "door"         // 车门未关 0/1
    static let tireTemp     = "tpms_temp"    // 四轮温度 [FL,FR,RL,RR] ℃
    static let headlight    = "headlight"    // 大灯 0/1
    static let hazard       = "hazard"       // 双闪警示灯 0/1
    static let autohold     = "autohold"     // 自动驻车 Auto Hold 0/1
    static let trunk        = "trunk"        // 尾门未关 0/1
    static let frunk        = "frunk"        // 前备箱未关 0/1
    static let esp          = "esp"          // ESP 车身稳定报警 0/1

    // 导航详情（由 TITA / BLE 推送，字段同样需真机确认）
    static let navEta       = "nav_eta"      // 预计到达时间 "14:30" 或剩余秒数
    static let navRemainKm  = "nav_remain"   // 剩余距离 km
    static let navArrivalSoc = "nav_arrival_soc" // 到达预计电量 %
    static let navRoad      = "nav_road"     // 当前所在路段名
    static let navTurn      = "nav_turn"     // 下一步转向文字（含出口/目的地）
    static let navExit      = "nav_exit"     // 出口编号（数字或字符串）
}

// MARK: - 解码后的统一数据帧
struct TitaFrame {
    var speedKmh: Double?
    var gear: Gear?
    var batteryPercent: Int?
    var rangeKm: Double?
    var odometerKm: Double?
    var outsideTempC: Double?
    var insideTempC: Double?
    var powerKw: Double?
    var leftTurnSignal: Bool?
    var rightTurnSignal: Bool?
    var autopilotActive: Bool?
    var blindSpotLeft: Bool?
    var blindSpotRight: Bool?
    var tirePressure: [Double]?
    var brakeActive: Bool?
    var speedLimitKmh: Int?
    var seatbeltFastened: Bool?
    var trafficLight: String?      // "red" / "green" / "none"
    var doorAjar: Bool?
    var tireTemperature: [Double]? // 四轮温度 ℃
    var headlightsOn: Bool?        // 大灯
    var hazardOn: Bool?            // 双闪
    var autoholdActive: Bool?      // 自动驻车
    var trunkOpen: Bool?           // 尾门未关
    var frunkOpen: Bool?           // 前备箱未关
    var espActive: Bool?           // ESP 报警

    // 导航详情
    var navEta: String?            // 预计到达 "14:30"
    var navRemainKm: Double?       // 剩余距离 km
    var navArrivalSoc: Int?        // 到达预计电量 %
    var navRoad: String?           // 当前路段名
    var navTurn: String?           // 下一步转向文字
    var navExit: String?           // 出口编号
}

// MARK: - 帧解析器
enum TitaFrameParser {

    /// 解析一帧文本消息（JSON）。返回 nil 表示无法识别（可能是心跳/握手包）。
    static func parse(text: String) -> TitaFrame? {
        guard let data = text.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return nil }
        return parse(json: obj)
    }

    static func parse(json: [String: Any]) -> TitaFrame {
        var frame = TitaFrame()
        // 候选 key：Dashla bundle 真实字段名优先，旧约定兼容
        frame.speedKmh      = num(pick(json, ["compositeSpeedKph", "speedKph", FieldKey.speed, "rawGpsSpeed"]))
        frame.gear          = parseGear(pick(json, ["vehicleGear", "currentGear", FieldKey.gear]))
        frame.batteryPercent = num(pick(json, ["batteryPercent", "soc", FieldKey.battery])).map { Int($0.rounded()) }
        frame.rangeKm       = num(pick(json, ["batteryRangeValue", FieldKey.range, "rangeKm"]))
        // 真机若上报 carOdometerM（单位米）转换为 km；否则按 odo（km）处理
        if let odoM = num(json["carOdometerM"]) {
            frame.odometerKm = odoM / 1000.0
        } else {
            frame.odometerKm = num(json[FieldKey.odometer])
        }
        frame.outsideTempC  = num(pick(json, ["outsideTemperatureReading", FieldKey.outsideTemp, "ambientTemp"]))
        frame.insideTempC   = num(pick(json, ["insideTemperature", FieldKey.insideTemp, "cabinTemp"]))
        frame.powerKw       = num(pick(json, ["frontPowerKw", FieldKey.power, "powerKw"]))
        frame.leftTurnSignal  = bool(pick(json, [FieldKey.leftSignal, "turnSignalLeft", "leftTurn"]))
        frame.rightTurnSignal = bool(pick(json, [FieldKey.rightSignal, "turnSignalRight", "rightTurn"]))
        frame.autopilotActive = bool(pick(json, [FieldKey.autopilot, "autopilot", "autosteer"]))
        frame.blindSpotLeft   = bool(pick(json, ["blindSpot.left", FieldKey.blindLeft, "blindSpotLeft"]))
        frame.blindSpotRight  = bool(pick(json, ["blindSpot.right", FieldKey.blindRight, "blindSpotRight"]))
        frame.brakeActive     = bool(pick(json, [FieldKey.brake, "brakeLight", "brakePedal"]))
        frame.speedLimitKmh   = num(pick(json, ["titaSpeedLimitKph", FieldKey.speedLimit, "speedLimitKmh"])).map { Int($0) }
        // titaAnySeatbeltUnbuckled 语义为「任一未系」(true=未系)，需取反为「已系」
        if let unbuckled = bool(json["titaAnySeatbeltUnbuckled"]) {
            frame.seatbeltFastened = !unbuckled
        } else {
            frame.seatbeltFastened = bool(pick(json, [FieldKey.seatbelt, "seatBelt", "CarSeatbelt"]))
        }
        frame.trafficLight    = json[FieldKey.trafficLight] as? String
        frame.doorAjar        = bool(json[FieldKey.doorAjar])
        if let arr = json[FieldKey.tirePressure] as? [Any] {
            frame.tirePressure = arr.compactMap { num($0) }
        }
        if let arr = json[FieldKey.tireTemp] as? [Any] {
            frame.tireTemperature = arr.compactMap { num($0) }
        }
        frame.headlightsOn = bool(json[FieldKey.headlight])
        frame.hazardOn     = bool(json[FieldKey.hazard])
        frame.autoholdActive = bool(json[FieldKey.autohold])
        frame.trunkOpen    = bool(json[FieldKey.trunk])
        frame.frunkOpen    = bool(json[FieldKey.frunk])
        frame.espActive    = bool(json[FieldKey.esp])

        // 导航详情
        if let s = json[FieldKey.navEta] as? String {
            frame.navEta = s
        } else if let n = num(json[FieldKey.navEta]) {
            // 若是剩余秒数，转换成 "HH:MM"（到达时刻）
            let arrive = Date().addingTimeInterval(n)
            let fmt = DateFormatter(); fmt.dateFormat = "HH:mm"
            frame.navEta = fmt.string(from: arrive)
        }
        frame.navRemainKm  = num(json[FieldKey.navRemainKm])
        frame.navArrivalSoc = num(json[FieldKey.navArrivalSoc]).map { Int($0.rounded()) }
        frame.navRoad      = json[FieldKey.navRoad] as? String
        frame.navTurn      = json[FieldKey.navTurn] as? String
        if let s = json[FieldKey.navExit] as? String {
            frame.navExit = s
        } else if let n = num(json[FieldKey.navExit]) {
            frame.navExit = "\(Int(n))"
        }
        return frame
    }

    /// 二进制帧入口：Dashla 内部使用二进制帧（bundle 里有 parseFrame / FieldKey / getUint8/16/32）。
    /// 字段语义已在《Dashla逆向分析.md》列出，但字节偏移仍在 Hermes 字节码中，需真机帧日志确认。
    /// 拿到形如 `RECV xxB <hex>` 的真实帧后，按下方表格填入偏移即可打通数据层。
    static func parse(binary data: Data) -> TitaFrame? {
        guard data.count >= 8 else { return nil }
        // ---- 真机联调填表区（偏移/缩放待 real frame 确认）----
        // let b = [UInt8](data)
        // frame.speedKmh       = Double(b[1]) * 0.5          // compositeSpeedKph
        // frame.batteryPercent = Int(b[2])                   // soc
        // frame.gear           = [.park,.reverse,.neutral,.drive][safe: Int(b[3] & 0x03)]
        // frame.outsideTempC   = Double(Int8(bitPattern: b[4])) // 有符号温度
        // frame.speedLimitKmh  = Int(b[5])
        // 位标志字节 b[6]/b[7]：bit0 左转向 / bit1 右转向 / bit2 刹车 /
        //                      bit3 盲点左 / bit4 盲点右 / bit5 AP / bit6 双闪 / bit7 安全带
        // ---- 未确认前返回 nil，避免用错误偏移污染 UI ----
        return nil
    }

    // MARK: - 工具
    /// 按候选 key 顺序取值（第一个命中的非 nil）。key 来自 Dashla bundle 逆向 + 旧约定兼容。
    private static func pick(_ json: [String: Any], _ keys: [String]) -> Any? {
        for k in keys {
            if let v = json[k] { return v }
        }
        return nil
    }

    private static func num(_ any: Any?) -> Double? {
        switch any {
        case let n as NSNumber: return n.doubleValue
        case let s as String:   return Double(s)
        default:                return nil
        }
    }

    private static func bool(_ any: Any?) -> Bool? {
        switch any {
        case let n as NSNumber: return n.boolValue
        case let s as String:   return ["1", "true", "on"].contains(s.lowercased())
        default:                return nil
        }
    }

    private static func parseGear(_ any: Any?) -> Gear? {
        switch any {
        case let s as String:
            return Gear(rawValue: s.uppercased())
        case let n as NSNumber:
            // 部分固件用数字：0=P 1=R 2=N 3=D
            return [Gear.park, .reverse, .neutral, .drive][safe: n.intValue]
        default:
            return nil
        }
    }
}

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
