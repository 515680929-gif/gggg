import SwiftUI

/// 仪表盘全局视觉常量（配色参照 Dashla 资源表 + 视频取色）
enum DashboardTheme {
    static let background = Color.black
    static let panelBackground = Color(white: 0.08)
    static let ringTrack = Color(white: 0.16)
    static let primaryText = Color.white
    static let secondaryText = Color(white: 0.55)
    static let placeholder = Color(white: 0.35)

    static let accentGreen = Color(red: 0.30, green: 0.85, blue: 0.45)   // 正常电量
    static let accentOrange = Color(red: 1.00, green: 0.62, blue: 0.10)  // 低电量
    static let accentRed = Color(red: 0.95, green: 0.30, blue: 0.25)     // 告警

    // Dashla 信号灯专用色（精确对齐从 index.android.bundle 提取的色值）
    // #2B63E8 / #007aff 主题蓝 · #16A24A 绿 · #FFD60A 黄 · #A42828 / #ff3b30 红
    static let signalBlue = Color(hex: 0x2B63E8)     // AP 蓝 #2B63E8
    static let signalGreen = Color(hex: 0x16A24A)    // 转向/通行绿 #16A24A
    static let signalAmber = Color(hex: 0xFFD60A)    // 盲点/黄灯 #FFD60A
    static let signalRed = Color(hex: 0xA42828)      // 刹车/告警红 #A42828
    static let signalRedBright = Color(hex: 0xFF3B30)// 高亮告警红 #ff3b30
    static let dashBackground = Color(hex: 0x0A0A0A) // 仪表盘纯黑底 #0A0A0A
    static let dashPanel = Color(hex: 0x141824)      // 面板底 #141824
    static let dashSecondary = Color(hex: 0x8A8A8A)  // 次要文字 #8A8A8A

    static let gearActive = Color.white
    static let gearInactive = Color(white: 0.32)

    /// 彩虹速度弧渐变（Dashla speedometerrainbowpreview：绿→黄→橙→红）
    static let speedRainbow = AngularGradient(
        gradient: Gradient(colors: [
            Color(red: 0.16, green: 0.90, blue: 0.45),
            Color(red: 0.75, green: 0.95, blue: 0.25),
            Color(red: 1.00, green: 0.78, blue: 0.15),
            Color(red: 1.00, green: 0.48, blue: 0.12),
            Color(red: 1.00, green: 0.25, blue: 0.22)
        ]),
        center: .center,
        startAngle: .degrees(0),
        endAngle: .degrees(270)
    )

    /// 数字使用等宽字体，避免刷新时抖动
    static func monoDigit(size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .rounded).monospacedDigit()
    }

    static func batteryColor(for percent: Int?) -> Color {
        guard let p = percent else { return placeholder }
        if p <= 15 { return accentRed }
        if p <= 30 { return accentOrange }
        return accentGreen
    }
}

// MARK: - Hex 色值便利构造（对齐 Dashla 资源精确色值）
extension Color {
    init(hex: UInt32, alpha: Double = 1.0) {
        let r = Double((hex >> 16) & 0xFF) / 255.0
        let g = Double((hex >> 8) & 0xFF) / 255.0
        let b = Double(hex & 0xFF) / 255.0
        self.init(.sRGB, red: r, green: g, blue: b, opacity: alpha)
    }
}
